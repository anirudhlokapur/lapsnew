package com.capgemini.laps.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.laps.bean.CustomerBean;
import com.capgemini.laps.exception.CustomerException;
import com.capgemini.laps.service.CustomerServiceImpl;
import com.capgemini.laps.service.ICustomerService;


public class MainApp {
	static Scanner sc = new Scanner(System.in);

	
	static ICustomerService customerService = null;
	static CustomerServiceImpl customerServiceImpl = null;
	static Logger logger = Logger.getRootLogger();


	public static void main(String[] args)
	{
		PropertyConfigurator.configure("resources//log4j.properties");
		CustomerBean customerBean=null;
		String customerId = null;
		int option = 0;
System.out.println("LOAN APPLICATION PROCESSING ");
System.out.println("LOGIN IN AS");
System.out.println("1. CUSTOMER");
System.out.println("2. LOAN APLLICATION PROCESSING DEPARTMENT");
System.out.println("Enter your choice");
option=sc.nextInt();


	switch(option)
	{
	case 1:
	{
		int choice=0;
		System.out.println("WELCOME");
		System.out.println("1. APPLY LOAN");
		System.out.println("2. VIEW LOAN APPLICATION STATUS BY CUSTOMER ID");
		System.out.println("3. EXIT");
		System.out.println("ENTER YOUR CHOICE");
		choice=sc.nextInt();
		while(true)
	{
		switch(choice)
		{
		case 1:
			{while (customerBean == null) {
				customerBean = populateCustomerBean();
				// System.out.println(donorBean);
			}

			try {
				customerService = new CustomerServiceImpl();
				customerId = customerService.addCustomerDetails(customerBean);

				System.out
						.println("customer details  has been successfully registered ");
				System.out.println("Customer ID Is: " + customerId);

			} catch (CustomerException customerException) {
				logger.error("exception occured", customerException);
				System.out.println("ERROR : "
						+ customerException.getMessage());
			} finally {
				customerId = null;
				customerService = null;
				customerBean = null;
			}

			break;
			}
			
		case 2:
		{
			customerServiceImpl = new CustomerServiceImpl();

			System.out.println("Enter numeric customer id:");
			customerId = sc.next();

			while (true) {
				if (customerServiceImpl.validateCustomerId(customerId)) {
					break;
				} else {
					System.err
							.println("Please enter numeric donor id only, try again");
				    customerId = sc.next();
				}
			}

			customerBean = getCustomerDetails(customerId);

			if (customerBean != null) {
				System.out.println("Name             :"
						+ customerBean.getCustomerName());
				System.out.println("Address          :"
						+ customerBean.getAddress());
				System.out.println("Phone Number     :"
						+ customerBean.getPhoneNumber());
//				System.out.println("Donor Date       :"
//						+ donorBean.getDonationDate());
				System.out.println("Loan Amount  :"
						+ customerBean.getLoanAmount());
			} else {
				System.err
						.println("There are no loan details associated with customer id "
								+ customerId);
			}

			break;
		}
		case 3:
		{
			System.out.print("Exit Trust Application");
			System.exit(0);
			break;
		
			
		}
		default:
		{
			System.out.println("Sorry Invalid Choice");
		}
		
	}
		
	}
	}
	case 2:
	{
		
	}
	}
	
		

		

	}


	private static CustomerBean getCustomerDetails(String customerId) {
		// TODO Auto-generated method stub
		return null;
	}


	private static CustomerBean populateCustomerBean() {
		// TODO Auto-generated method stub
		return null;
	}

}
