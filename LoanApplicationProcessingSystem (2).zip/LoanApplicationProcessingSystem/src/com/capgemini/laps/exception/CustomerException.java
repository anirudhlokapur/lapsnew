package com.capgemini.laps.exception;



public class CustomerException extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public CustomerException(String message) 
	{
		
		super(message);
	}
}
